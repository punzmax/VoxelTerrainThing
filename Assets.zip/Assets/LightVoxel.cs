using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightVoxel : Voxel 
{

    public LightVoxel(int type, Vector3Int position) : base(type, position)
    {
        
    }
    


}
