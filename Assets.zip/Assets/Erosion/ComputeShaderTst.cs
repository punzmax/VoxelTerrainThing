using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComputeShaderTst : MonoBehaviour
{
    public ComputeShader comp;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
